package com.example.android.moviebuff;

public class RecyclerViewAdapter {
}
